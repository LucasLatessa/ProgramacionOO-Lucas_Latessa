package modelo;

public enum Palo {
		ESPADA, BASTO,COPA,ORO
}
